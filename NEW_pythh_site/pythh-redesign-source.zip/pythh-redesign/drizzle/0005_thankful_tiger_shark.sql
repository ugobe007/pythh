CREATE TABLE `investors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`firm` varchar(128) NOT NULL,
	`sector` varchar(64) NOT NULL,
	`sector2` varchar(64),
	`signal` int NOT NULL,
	`delta` int NOT NULL DEFAULT 0,
	`god` int NOT NULL,
	`vcpp` int NOT NULL,
	`checkSize` varchar(32),
	`stage` varchar(64),
	`geo` varchar(64),
	`recentActivity` varchar(128),
	`profileUrl` varchar(256),
	`isPublic` int unsigned NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `investors_id` PRIMARY KEY(`id`)
);
