CREATE TABLE `pipelineFeedback` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`runId` varchar(64) NOT NULL,
	`rating` enum('up','down') NOT NULL,
	`comment` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pipelineFeedback_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `pipelineFeedback` ADD CONSTRAINT `pipelineFeedback_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;