CREATE TABLE `outreachEmails` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`runId` varchar(64) NOT NULL,
	`investorName` varchar(128) NOT NULL,
	`investorFirm` varchar(128) NOT NULL,
	`toEmail` varchar(256),
	`subject` varchar(256) NOT NULL,
	`body` text NOT NULL,
	`status` enum('draft','approved','sent') NOT NULL DEFAULT 'draft',
	`sentAt` bigint,
	`resendMessageId` varchar(128),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `outreachEmails_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pitchDecks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`runId` varchar(64) NOT NULL,
	`startupUrl` varchar(512),
	`sourceType` enum('uploaded','generated') NOT NULL DEFAULT 'generated',
	`fileKey` varchar(256),
	`slidesJson` text NOT NULL DEFAULT ('[]'),
	`status` enum('draft','ready','approved') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pitchDecks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `outreachEmails` ADD CONSTRAINT `outreachEmails_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `pitchDecks` ADD CONSTRAINT `pitchDecks_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;