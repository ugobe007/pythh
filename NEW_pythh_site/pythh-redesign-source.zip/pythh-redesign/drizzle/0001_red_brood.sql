CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`stripeCustomerId` varchar(64) NOT NULL,
	`stripeSubscriptionId` varchar(64) NOT NULL,
	`plan` enum('oracle') NOT NULL DEFAULT 'oracle',
	`billingCycle` enum('monthly','annual') NOT NULL,
	`status` enum('active','past_due','canceled','unpaid','trialing') NOT NULL DEFAULT 'active',
	`currentPeriodEnd` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `subscriptions_stripeSubscriptionId_unique` UNIQUE(`stripeSubscriptionId`)
);
